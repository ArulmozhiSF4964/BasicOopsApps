﻿using System;

namespace SYNCCART;
public class Program{
    public static void Main(string[] args){
        Operations operation = new Operations();
        operation.DefaultData();
        operation.MainMenu();
    }
}
