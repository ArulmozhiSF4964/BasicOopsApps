namespace SYNCCART
{
    public enum OrderStatus
    {
       Default, Ordered, Cancelled
    }
}