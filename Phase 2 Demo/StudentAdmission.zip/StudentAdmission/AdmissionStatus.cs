namespace StudentAdmission
{
    public enum AdmissionStatus
    {
    
        Select, Cancelled, Booked
    }
}