namespace StudentAdmission
{
    public enum GenderDetails
    {
        Unknown, Male,Female,Transgender
    }
}