﻿namespace StudentAdmission;

public class Program
{
    public static void Main(String[] agrs){

              Operations operation=new Operations();
              operation.DefaultData();
              operation.MainMenu();
         }
    }
    
